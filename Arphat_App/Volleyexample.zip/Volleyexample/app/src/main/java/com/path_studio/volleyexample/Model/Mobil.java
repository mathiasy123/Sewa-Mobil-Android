package com.path_studio.volleyexample.Model;

public class Mobil {

    private int id_jenis;
    private String plat;
    private int kursi;
    private int harga;
    private String status;

    public Mobil(){}

    public Mobil(int id_jenis, String plat, int kursi, int harga, String status) {
        this.id_jenis = id_jenis;
        this.plat = plat;
        this.kursi = kursi;
        this.harga = harga;
        this.status = status;
    }

    public int getId_jenis() {
        return id_jenis;
    }

    public void setId_jenis(int id_jenis) {
        this.id_jenis = id_jenis;
    }

    public String getPlat() {
        return plat;
    }

    public void setPlat(String plat) {
        this.plat = plat;
    }

    public int getKursi() {
        return kursi;
    }

    public void setKursi(int kursi) {
        this.kursi = kursi;
    }

    public int getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }

    public String getStatus() {
        return status;
    }
}
